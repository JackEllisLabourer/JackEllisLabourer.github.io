<!DOCTYPE html>
<html>
<title>Coming Soon</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<head>
    <link rel="stylesheet" href="./css/style.css">
</head>
<body>
    <canvas></canvas>
    <div class="overlay"></div>
    
    <div class="header">
        
    </div>
    
    
    <script src="./js/script.js"></script>
</body>
</html>
